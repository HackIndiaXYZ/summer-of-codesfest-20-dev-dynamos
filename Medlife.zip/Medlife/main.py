import os
import json
import math
import uuid
from datetime import datetime
from typing import Optional, List
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request, Query, UploadFile, File, Body
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Load .env manually if dotenv is available or manually parse .env file
env_path = Path(__file__).parent / ".env"
if env_path.exists():
    with open(env_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()

# Try initializing GenAI client if key exists
genai_client = None
if GEMINI_API_KEY:
    try:
        from google import genai
        genai_client = genai.Client(api_key=GEMINI_API_KEY)
    except Exception as e:
        print(f"Warning: Could not initialize Gemini client: {e}")
        genai_client = None

app = FastAPI(title="MedLife API", version="1.0.0")

# Enable CORS for all origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
CONTACTS_FILE = BASE_DIR / "contacts.json"
HOSPITALS_FILE = DATA_DIR / "hospitals.json"
FIRST_AID_OFFLINE_FILE = DATA_DIR / "first_aid_offline.json"
SOS_LOGS_FILE = BASE_DIR / "sos_logs.json"

# Global Error Handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500 if not isinstance(exc, HTTPException) else exc.status_code,
        content={
            "success": False,
            "data": None,
            "error": str(exc.detail) if isinstance(exc, HTTPException) else str(exc)
        }
    )

# File Helpers
def load_json(filepath: Path, default_val=None):
    if not filepath.exists():
        return default_val if default_val is not None else []
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default_val if default_val is not None else []

def save_json(filepath: Path, data):
    filepath.parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# Haversine Distance Helper (in KM)
def haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371.0  # Earth radius in kilometers
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(dlon / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return round(R * c, 2)

# Models
class ClassifyRequest(BaseModel):
    description: str
    language: Optional[str] = "en"

class SOSRequest(BaseModel):
    lat: float
    lng: float
    address: Optional[str] = "Unknown Location"
    contact_id: Optional[str] = None

class ContactModel(BaseModel):
    name: str
    phone: str
    relation: str
    is_primary: Optional[bool] = False

# ENDPOINT 1 — AI Text Classification
@app.post("/ai/classify")
async def classify_emergency(req: ClassifyRequest):
    desc = req.description.strip()
    lang = (req.language or "en").lower()

    if not desc:
        raise HTTPException(status_code=400, detail="Description is required")

    # Try Gemini API if client available
    if genai_client:
        try:
            from google.genai import types
            prompt = f"""
            You are an emergency first-aid AI assistant.
            Analyze the following emergency description and return ONLY a raw JSON object with NO markdown formatting, matching this exact schema:
            {{
              "emergency_type": "Short descriptive name of emergency",
              "severity": "low" | "medium" | "high" | "critical",
              "steps": ["Step 1 explanation", "Step 2 explanation", "Step 3 explanation", "Step 4 explanation", "Step 5 explanation"]
            }}

            Requested Language for response text: '{lang}'. Ensure emergency_type and all steps are written in target language '{lang}' (e.g. English, Hindi, or Tamil).

            Emergency Description:
            "{desc}"
            """

            response = genai_client.models.generate_content(
                model='gemini-2.5-flash',
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json"
                )
            )

            raw_text = response.text.strip()
            if raw_text.startswith("```json"):
                raw_text = raw_text[7:]
            if raw_text.endswith("```"):
                raw_text = raw_text[:-3]

            parsed = json.loads(raw_text.strip())
            return {
                "success": True,
                "source": "ai",
                "emergency_type": parsed.get("emergency_type", "Medical Emergency"),
                "severity": parsed.get("severity", "high"),
                "steps": parsed.get("steps", [])
            }
        except Exception as e:
            print(f"Gemini API classification failed, falling back to offline: {e}")

    # Fallback keyword matching against first_aid_offline.json
    offline_data = load_json(FIRST_AID_OFFLINE_FILE, {})
    desc_lower = desc.lower()

    matched_key = None
    best_score = 0

    for key, item in offline_data.items():
        score = sum(1 for kw in item.get("keywords", []) if kw in desc_lower)
        if score > best_score:
            best_score = score
            matched_key = key

    # If no keyword matched, check direct emergency_type match or default to fainting/general
    if not matched_key:
        for key in offline_data:
            if key in desc_lower or key.replace("_", " ") in desc_lower:
                matched_key = key
                break

    if not matched_key:
        matched_key = "fainting"

    protocol = offline_data[matched_key]
    emergency_type = protocol["emergency_type"]
    steps = protocol["steps"]

    # Localized translation fallback if available
    if lang in protocol.get("translations", {}):
        trans = protocol["translations"][lang]
        emergency_type = trans.get("emergency_type", emergency_type)
        steps = trans.get("steps", steps)

    return {
        "success": True,
        "source": "offline",
        "emergency_type": emergency_type,
        "severity": protocol.get("severity", "high"),
        "steps": steps
    }

# ENDPOINT 2 — AI Image Analysis
@app.post("/ai/analyze-image")
async def analyze_image(file: UploadFile = File(...)):
    contents = await file.read()
    content_type = file.content_type or "image/jpeg"

    if genai_client:
        try:
            from google.genai import types
            image_part = types.Part.from_bytes(data=contents, mime_type=content_type)
            prompt = """
            You are a medical first-aid AI visual diagnostic tool.
            Examine this injury photo and return ONLY a raw JSON object with NO markdown formatting, matching this exact schema:
            {
              "injury_type": "Identified Injury / Condition",
              "severity": "low" | "medium" | "high" | "critical",
              "steps": ["First-aid step 1", "First-aid step 2", "First-aid step 3", "First-aid step 4"]
            }
            """

            response = genai_client.models.generate_content(
                model='gemini-2.5-flash',
                contents=[image_part, prompt],
                config=types.GenerateContentConfig(
                    response_mime_type="application/json"
                )
            )

            raw_text = response.text.strip()
            if raw_text.startswith("```json"):
                raw_text = raw_text[7:]
            if raw_text.endswith("```"):
                raw_text = raw_text[:-3]

            parsed = json.loads(raw_text.strip())
            return {
                "success": True,
                "source": "ai",
                "analysis": {
                    "injury_type": parsed.get("injury_type", "Observed Trauma"),
                    "severity": parsed.get("severity", "medium"),
                    "steps": parsed.get("steps", [])
                }
            }
        except Exception as e:
            print(f"Gemini image analysis failed: {e}")

    # Fallback if Gemini unavailable
    return {
        "success": True,
        "source": "offline",
        "analysis": {
            "injury_type": "Visual Inspection Required (Offline)",
            "severity": "medium",
            "steps": [
                "Examine the affected area for active bleeding, deep lacerations, or bone deformity.",
                "If bleeding is present, apply firm, continuous pressure with a clean sterile cloth.",
                "Rinse minor cuts or surface abrasions with clean water.",
                "Please describe the injury in text input for dedicated step-by-step guidance."
            ]
        }
    }

# ENDPOINT 3 — Nearby Hospitals
@app.get("/hospitals/nearby")
async def get_nearby_hospitals(
    lat: float = Query(..., description="Latitude"),
    lng: float = Query(..., description="Longitude"),
    specialty: Optional[str] = Query(None, description="Optional specialty filter")
):
    hospitals = load_json(HOSPITALS_FILE, [])

    results = []
    for h in hospitals:
        dist = haversine(lat, lng, h["lat"], h["lng"])
        h_copy = dict(h)
        h_copy["distance_km"] = dist
        h_copy["maps_url"] = f"https://maps.google.com/?q={h['lat']},{h['lng']}"

        # Filter by specialty if requested
        if specialty and specialty.strip():
            spec_filter = specialty.strip().lower()
            h_specs = [s.lower() for s in h_copy.get("specialties", [])]
            if not any(spec_filter in s for s in h_specs):
                continue

        results.append(h_copy)

    # Sort by distance
    results.sort(key=lambda x: x["distance_km"])

    return {
        "success": True,
        "hospitals": results
    }

# ENDPOINT 4 — SOS Dispatch
@app.post("/sos")
async def trigger_sos(req: SOSRequest):
    contacts = load_json(CONTACTS_FILE, [])

    # Find contact
    target_contact = None
    if req.contact_id:
        target_contact = next((c for c in contacts if c.get("id") == req.contact_id), None)
    if not target_contact:
        target_contact = next((c for c in contacts if c.get("is_primary")), None)
    if not target_contact and contacts:
        target_contact = contacts[0]

    contact_name = target_contact["name"] if target_contact else "Primary Emergency Contact"

    # Get top 3 hospitals
    all_hospitals = load_json(HOSPITALS_FILE, [])
    for h in all_hospitals:
        h["distance_km"] = haversine(req.lat, req.lng, h["lat"], h["lng"])
        h["maps_url"] = f"https://maps.google.com/?q={h['lat']},{h['lng']}"
    all_hospitals.sort(key=lambda x: x["distance_km"])
    top_3 = all_hospitals[:3]

    # Save to SOS logs
    sos_id = f"sos_{int(datetime.now().timestamp())}_{uuid.uuid4().hex[:4]}"
    sos_log = {
        "sos_id": sos_id,
        "timestamp": datetime.now().isoformat(),
        "lat": req.lat,
        "lng": req.lng,
        "address": req.address,
        "dispatched_to": contact_name,
        "status": "DISPATCHED"
    }

    logs = load_json(SOS_LOGS_FILE, [])
    logs.append(sos_log)
    save_json(SOS_LOGS_FILE, logs)

    return {
        "success": True,
        "sos_id": sos_id,
        "dispatched_to": contact_name,
        "hospitals": top_3
    }

# ENDPOINT 5 — Emergency Contacts CRUD
@app.get("/contacts")
async def get_contacts():
    contacts = load_json(CONTACTS_FILE, [])
    return {"success": True, "contacts": contacts}

@app.post("/contacts")
async def add_contact(contact: ContactModel):
    contacts = load_json(CONTACTS_FILE, [])

    new_id = f"cnt_{int(datetime.now().timestamp())}"
    new_contact = {
        "id": new_id,
        "name": contact.name.strip(),
        "phone": contact.phone.strip(),
        "relation": contact.relation.strip(),
        "is_primary": contact.is_primary
    }

    # Handle primary constraint
    if contact.is_primary:
        for c in contacts:
            c["is_primary"] = False

    # If first contact, make it primary automatically
    if not contacts:
        new_contact["is_primary"] = True

    contacts.append(new_contact)
    save_json(CONTACTS_FILE, contacts)
    return {"success": True, "contact": new_contact}

@app.put("/contacts/{contact_id}")
async def update_contact(contact_id: str, contact: ContactModel):
    contacts = load_json(CONTACTS_FILE, [])

    found_idx = None
    for idx, c in enumerate(contacts):
        if c.get("id") == contact_id:
            found_idx = idx
            break

    if found_idx is None:
        raise HTTPException(status_code=404, detail="Contact not found")

    if contact.is_primary:
        for c in contacts:
            c["is_primary"] = False

    updated = {
        "id": contact_id,
        "name": contact.name.strip(),
        "phone": contact.phone.strip(),
        "relation": contact.relation.strip(),
        "is_primary": contact.is_primary
    }

    contacts[found_idx] = updated
    save_json(CONTACTS_FILE, contacts)
    return {"success": True, "contact": updated}

@app.delete("/contacts/{contact_id}")
async def delete_contact(contact_id: str):
    contacts = load_json(CONTACTS_FILE, [])
    new_contacts = [c for c in contacts if c.get("id") != contact_id]

    if len(new_contacts) == len(contacts):
        raise HTTPException(status_code=404, detail="Contact not found")

    # If we deleted the primary contact, assign primary to first remaining contact
    if new_contacts and not any(c.get("is_primary") for c in new_contacts):
        new_contacts[0]["is_primary"] = True

    save_json(CONTACTS_FILE, new_contacts)
    return {"success": True, "message": "Contact deleted successfully"}

# Mount Static Files & Root Serve
static_dir = BASE_DIR / "static"
static_dir.mkdir(exist_ok=True)

app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

@app.get("/")
async def read_index():
    index_file = static_dir / "index.html"
    if index_file.exists():
        return FileResponse(index_file)
    return JSONResponse({"message": "MedLife API is running. Static index.html pending."})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
