# MedLife — AI Instant First-Aid & Emergency Care Connector

MedLife is an AI-powered instant first-aid guidance and emergency care connector built with FastAPI and vanilla JavaScript. It delivers real-time trauma triage, multimodal injury visual analysis, location-based hospital route planning, audio siren panic alerts, and hardware sensor integration.

---

## 🌟 Key Features

1. **SOS Panic Flow & Siren Dispatch**:
   - 2-second press-and-hold circular arming button with SVG progress ring feedback.
   - 3-second panic countdown with synthesized siren alert using Web Audio API.
   - Reverse geocoding of GPS location via Nominatim API.
   - Automatic `sms:` and `tel:` link generation to primary contact with pre-filled Google Maps coordinates.
   - Real-time logging of emergency events to `sos_logs.json`.

2. **AI & Offline First-Aid Triage**:
   - **Text Classification (`POST /ai/classify`)**: Uses Gemini 2.5 Flash API to categorize emergency description into structured steps and severity levels.
   - **Multimodal Visual Analysis (`POST /ai/analyze-image`)**: Accepts injury photos for visual assessment.
   - **Offline Fallback Protocol**: Automatically falls back to keyword matching against `data/first_aid_offline.json` if `GEMINI_API_KEY` is missing or offline.
   - **Multilingual Support**: Supports English, Hindi, and Tamil translation.
   - **Text-to-Speech (TTS)**: Reads step-by-step guidance aloud.

3. **Nearby Emergency Hospitals**:
   - Real Chennai dataset in `data/hospitals.json` with exact latitude and longitude coordinates.
   - Server-side Haversine distance algorithm sorting nearest trauma centers.
   - Specialty filters (Cardiology, Trauma ICU, General ER, Burn Unit).
   - Animated polyline navigation modal with 5 step-by-step waypoint instructions and ETA calculation.

4. **Hardware Studio & Sensors**:
   - Geolocation live tracking (`navigator.geolocation.watchPosition`).
   - Live camera stream preview and snapshot trigger (`getUserMedia`).
   - Real-time Audio decibel meter (`AudioContext` + `AnalyserNode`).
   - Web Speech API continuous voice listener for emergency trigger keywords (`"HELP"`, `"EMERGENCY"`).
   - Network connectivity indicator (`navigator.onLine`).

5. **Emergency Contacts Manager**:
   - Full CRUD endpoints (`/contacts`) persisted to `contacts.json`.
   - Single primary contact enforcement logic.

---

## 📁 Project Structure

```
c:\MedLife\
├── main.py                     # FastAPI server, endpoints, Gemini & Haversine logic
├── requirements.txt            # Python dependencies
├── .env.example                # Environment variables template
├── contacts.json               # Persisted emergency contacts dataset
├── data/
│   ├── hospitals.json          # Real Chennai hospitals dataset
│   └── first_aid_offline.json  # Pre-seeded 8 emergency offline protocols & translations
├── static/
│   ├── index.html              # Single page app interface
│   ├── styles.css              # Dark-mode glassmorphic styling system
│   └── app.js                  # Frontend controllers & Web API handlers
└── README.md                   # Documentation
```

---

## 🚀 Quick Start Guide

### 1. Environment Setup

Copy `.env.example` to `.env` and add your Gemini API key (optional - offline fallback works seamlessly without it):

```bash
copy .env.example .env
```

Edit `.env`:
```env
GEMINI_API_KEY=your_gemini_api_key_here
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Launch Application

Run the application with a single command:

```bash
python main.py
```
or
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Open your web browser and navigate to:
[http://localhost:8000](http://localhost:8000)

---

## 🧪 Testing API Endpoints

- **Text Classification**: `POST /ai/classify`
- **Image Analysis**: `POST /ai/analyze-image`
- **Nearby Hospitals**: `GET /hospitals/nearby?lat=13.0604&lng=80.2512&specialty=Cardiology`
- **SOS Dispatch**: `POST /sos`
- **Contacts CRUD**: `GET|POST|PUT|DELETE /contacts`
