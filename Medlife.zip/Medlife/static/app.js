/**
 * MedLife — AI Emergency Care & Instant First-Aid Assistant
 * Full Frontend Application Controller
 */

document.addEventListener('DOMContentLoaded', () => {

  // ==================== GLOBAL APP STATE ====================
  const state = {
    currentTab: 'sos-section',
    language: 'en',
    userLat: 13.0827, // Default Chennai coordinates
    userLng: 80.2707,
    hasLocation: false,
    contacts: [],
    primaryContact: null,
    selectedSpecialty: '',
    currentStepsForTTS: [],
    
    // SOS State
    isHoldingSOS: false,
    sosHoldProgress: 0,
    sosHoldInterval: null,
    sosCountdownVal: 3,
    sosCountdownInterval: null,
    audioCtx: null,
    sirenOsc1: null,
    sirenOsc2: null,
    
    // Hardware State
    watchPosId: null,
    camStream: null,
    audioStream: null,
    analyserNode: null,
    speechRecog: null,
    selectedImageFile: null
  };

  // UI Translation Dictionary
  const uiTranslations = {
    en: {
      sosTitle: "EMERGENCY ASSISTANT",
      sosSub: "Press & hold the SOS button for 2 seconds to trigger immediate response",
      sosBtnText: "HOLD FOR SOS",
      sosBtnSub: "Hold 2 Seconds",
      dispatchTitle: "Emergency Protocol Activated",
      readAloud: "Read Aloud",
      stopAloud: "Stop Speech"
    },
    hi: {
      sosTitle: "आपातकालीन सहायक (Emergency)",
      sosSub: "तत्काल सहायता के लिए 2 सेकंड तक एसओएस (SOS) बटन दबाकर रखें",
      sosBtnText: "SOS दबाकर रखें",
      sosBtnSub: "2 सेकंड तक दबाएं",
      dispatchTitle: "आपत्कालीन सेवा सक्रिय की गई",
      readAloud: "बोलकर सुनें",
      stopAloud: "आवाज बंद करें"
    },
    ta: {
      sosTitle: "அவசர உதவி மையம் (Emergency)",
      sosSub: "உடனடி உதவிக்கு SOS பொத்தானை 2 வினாடிகள் அழுத்திப் பிடிக்கவும்",
      sosBtnText: "SOS அழுத்தவும்",
      sosBtnSub: "2 வினாடி பிடிக்கவும்",
      dispatchTitle: "அவசர சேவை செயல்படுத்தப்பட்டது",
      readAloud: "வாசித்துக்காட்டு",
      stopAloud: "நிறுத்து"
    }
  };

  // ==================== INIT APPLICATION ====================
  function init() {
    setupTabNavigation();
    setupLanguageSelector();
    setupSOSArming();
    setupFirstAidGuidance();
    setupHospitalsSection();
    setupHardwareStudio();
    setupContactsManager();
    
    // Fetch initial location and contacts
    getUserLocation();
    loadContacts();
  }

  // ==================== TAB NAVIGATION ====================
  function setupTabNavigation() {
    const tabs = document.querySelectorAll('.nav-tab');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

        tab.classList.add('active');
        const targetId = tab.getAttribute('data-tab');
        document.getElementById(targetId).classList.add('active');
        state.currentTab = targetId;

        if (targetId === 'hospitals-section') {
          loadNearbyHospitals();
        }
      });
    });
  }

  // ==================== LANGUAGE SELECTOR ====================
  function setupLanguageSelector() {
    const selector = document.getElementById('language-selector');
    selector.addEventListener('change', (e) => {
      state.language = e.target.value;
      updateUILanguage();
    });
  }

  function updateUILanguage() {
    const dict = uiTranslations[state.language] || uiTranslations.en;
    document.getElementById('txt-sos-title').innerText = dict.sosTitle;
    document.getElementById('txt-sos-subtitle').innerText = dict.sosSub;
    document.querySelector('.sos-text').innerText = dict.sosBtnText;
    document.querySelector('.sos-subtext').innerText = dict.sosBtnSub;
  }

  // ==================== LOCATION HELPER ====================
  function getUserLocation() {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          state.userLat = pos.coords.latitude;
          state.userLng = pos.coords.longitude;
          state.hasLocation = true;
          updateGPSReadout(pos.coords);
          if (state.currentTab === 'hospitals-section') {
            loadNearbyHospitals();
          }
        },
        (err) => {
          console.warn("Geolocation warning:", err.message);
        },
        { enableHighAccuracy: true, timeout: 5000 }
      );
    }
  }

  // ==================== SECTION 1: SOS HOLD & SIREN CONTROLLER ====================
  function setupSOSArming() {
    const sosBtn = document.getElementById('sos-main-btn');
    const ringCircle = document.getElementById('sos-ring-circle');
    const circumference = 2 * Math.PI * 126; // 791.68

    const startHold = (e) => {
      if (e.type === 'touchstart') e.preventDefault();
      if (state.isHoldingSOS) return;

      state.isHoldingSOS = true;
      state.sosHoldProgress = 0;
      sosBtn.classList.add('holding');

      const startTime = Date.now();
      const holdDuration = 2000; // 2 seconds

      state.sosHoldInterval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        state.sosHoldProgress = Math.min(1, elapsed / holdDuration);
        const offset = circumference * (1 - state.sosHoldProgress);
        ringCircle.style.strokeDashoffset = offset;

        if (state.sosHoldProgress >= 1) {
          stopHold();
          triggerPanicCountdown();
        }
      }, 30);
    };

    const stopHold = () => {
      if (!state.isHoldingSOS) return;
      state.isHoldingSOS = false;
      clearInterval(state.sosHoldInterval);
      sosBtn.classList.remove('holding');
      ringCircle.style.strokeDashoffset = circumference;
    };

    sosBtn.addEventListener('mousedown', startHold);
    sosBtn.addEventListener('mouseup', stopHold);
    sosBtn.addEventListener('mouseleave', stopHold);

    sosBtn.addEventListener('touchstart', startHold, { passive: false });
    sosBtn.addEventListener('touchend', stopHold);
    sosBtn.addEventListener('touchcancel', stopHold);

    document.getElementById('btn-cancel-sos').addEventListener('click', cancelPanicCountdown);
  }

  // Web Audio API Siren Generator
  function playSiren() {
    try {
      if (!state.audioCtx) {
        state.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      }
      if (state.audioCtx.state === 'suspended') {
        state.audioCtx.resume();
      }

      state.sirenOsc1 = state.audioCtx.createOscillator();
      const gainNode = state.audioCtx.createGain();

      state.sirenOsc1.type = 'sawtooth';
      state.sirenOsc1.frequency.setValueAtTime(600, state.audioCtx.currentTime);
      
      // Siren frequency ramp up and down
      const now = state.audioCtx.currentTime;
      state.sirenOsc1.frequency.linearRampToValueAtTime(1200, now + 0.5);
      state.sirenOsc1.frequency.linearRampToValueAtTime(600, now + 1.0);
      state.sirenOsc1.frequency.linearRampToValueAtTime(1200, now + 1.5);
      state.sirenOsc1.frequency.linearRampToValueAtTime(600, now + 2.0);
      state.sirenOsc1.frequency.linearRampToValueAtTime(1200, now + 2.5);

      gainNode.gain.setValueAtTime(0.3, now);

      state.sirenOsc1.connect(gainNode);
      gainNode.connect(state.audioCtx.destination);

      state.sirenOsc1.start();
    } catch (e) {
      console.warn("Web Audio Siren error:", e);
    }
  }

  function stopSiren() {
    try {
      if (state.sirenOsc1) {
        state.sirenOsc1.stop();
        state.sirenOsc1.disconnect();
        state.sirenOsc1 = null;
      }
    } catch (e) {}
  }

  function triggerPanicCountdown() {
    state.sosCountdownVal = 3;
    document.getElementById('countdown-val').innerText = state.sosCountdownVal;
    document.getElementById('modal-countdown').classList.remove('hidden');

    playSiren();

    state.sosCountdownInterval = setInterval(() => {
      state.sosCountdownVal--;
      document.getElementById('countdown-val').innerText = state.sosCountdownVal;

      if (state.sosCountdownVal <= 0) {
        clearInterval(state.sosCountdownInterval);
        stopSiren();
        document.getElementById('modal-countdown').classList.add('hidden');
        executeSOSDispatch();
      }
    }, 1000);
  }

  function cancelPanicCountdown() {
    clearInterval(state.sosCountdownInterval);
    stopSiren();
    document.getElementById('modal-countdown').classList.add('hidden');
  }

  async function executeSOSDispatch() {
    let addressStr = "Chennai, Tamil Nadu, India";

    // Reverse geocode location via Nominatim API
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${state.userLat}&lon=${state.userLng}`);
      if (res.ok) {
        const geoData = await res.json();
        addressStr = geoData.display_name || addressStr;
      }
    } catch (e) {
      console.warn("Reverse geocode fallback used");
    }

    // Call POST /sos
    try {
      const res = await fetch('/sos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lat: state.userLat,
          lng: state.userLng,
          address: addressStr
        })
      });

      const data = await res.json();

      if (data.success) {
        showSOSDispatchConfirmation(data, addressStr);
      }
    } catch (e) {
      console.error("SOS trigger failed:", e);
    }
  }

  function showSOSDispatchConfirmation(data, addressStr) {
    const card = document.getElementById('sos-dispatch-card');
    card.classList.remove('hidden');

    document.getElementById('dispatch-sos-id').innerText = `ID: ${data.sos_id}`;
    document.getElementById('sos-current-addr').innerText = addressStr;
    document.getElementById('sos-notified-contact').innerText = `${data.dispatched_to}`;

    // Setup SMS & TEL links
    const primary = state.contacts.find(c => c.is_primary) || state.contacts[0];
    const phone = primary ? primary.phone : "+91108";
    const mapsUrl = `https://maps.google.com/?q=${state.userLat},${state.userLng}`;
    const smsBody = encodeURIComponent(`EMERGENCY SOS ALERT! I need immediate medical assistance at: ${addressStr}. Location: ${mapsUrl}`);

    document.getElementById('sos-sms-link').setAttribute('href', `sms:${phone}?body=${smsBody}`);
    document.getElementById('sos-call-link').setAttribute('href', `tel:${phone}`);

    // Render top 3 hospitals
    const listEl = document.getElementById('sos-hospitals-list');
    listEl.innerHTML = '';

    (data.hospitals || []).forEach(h => {
      const item = document.createElement('div');
      item.className = 'dispatch-hosp-item';
      item.innerHTML = `
        <div>
          <strong>${h.name}</strong>
          <div class="subtext"><i class="fa-solid fa-road"></i> ${h.distance_km} km away | wait time: ${h.er_wait_minutes} mins</div>
        </div>
        <a href="${h.maps_url}" target="_blank" class="btn btn-secondary btn-sm"><i class="fa-solid fa-location-arrow"></i> Maps</a>
      `;
      listEl.appendChild(item);
    });

    card.scrollIntoView({ behavior: 'smooth' });
  }

  // ==================== SECTION 2: FIRST-AID GUIDANCE CONTROLLER ====================
  function setupFirstAidGuidance() {
    // Quick emergency cards
    document.querySelectorAll('.emergency-card').forEach(card => {
      card.addEventListener('click', () => {
        const query = card.getAttribute('data-query');
        fetchFirstAidSteps(query);
      });
    });

    // Custom text form
    document.getElementById('form-classify-text').addEventListener('submit', (e) => {
      e.preventDefault();
      const val = document.getElementById('text-emergency-input').value;
      if (val) fetchFirstAidSteps(val);
    });

    // Image Upload Dropzone
    const dropzone = document.getElementById('image-dropzone');
    const fileInput = document.getElementById('file-image-input');
    const analyzeBtn = document.getElementById('btn-analyze-image');

    dropzone.addEventListener('click', () => fileInput.click());
    dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.classList.add('dragover');
    });
    dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
    dropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropzone.classList.remove('dragover');
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        handleImageSelect(e.dataTransfer.files[0]);
      }
    });

    fileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files[0]) {
        handleImageSelect(e.target.files[0]);
      }
    });

    document.getElementById('btn-remove-photo').addEventListener('click', (e) => {
      e.stopPropagation();
      resetImageDropzone();
    });

    analyzeBtn.addEventListener('click', uploadAndAnalyzeImage);

    // Text To Speech (TTS)
    document.getElementById('btn-tts-speak').addEventListener('click', toggleTTS);
  }

  function handleImageSelect(file) {
    state.selectedImageFile = file;
    const reader = new FileReader();
    reader.onload = (e) => {
      document.getElementById('img-preview-thumb').src = e.target.result;
      document.getElementById('dropzone-prompt').classList.add('hidden');
      document.getElementById('dropzone-preview').classList.remove('hidden');
      document.getElementById('btn-analyze-image').disabled = false;
    };
    reader.readAsDataURL(file);
  }

  function resetImageDropzone() {
    state.selectedImageFile = null;
    document.getElementById('file-image-input').value = '';
    document.getElementById('dropzone-prompt').classList.remove('hidden');
    document.getElementById('dropzone-preview').classList.add('hidden');
    document.getElementById('btn-analyze-image').disabled = true;
  }

  async function fetchFirstAidSteps(description) {
    showFirstAidLoading();

    try {
      const res = await fetch('/ai/classify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description, language: state.language })
      });
      const data = await res.json();

      if (data.success) {
        displayFirstAidResults(data.emergency_type, data.severity, data.steps, data.source);
      }
    } catch (e) {
      console.error("Failed to fetch first-aid steps:", e);
    }
  }

  async function uploadAndAnalyzeImage() {
    if (!state.selectedImageFile) return;
    showFirstAidLoading();

    const formData = new FormData();
    formData.append('file', state.selectedImageFile);

    try {
      const res = await fetch('/ai/analyze-image', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();

      if (data.success && data.analysis) {
        displayFirstAidResults(
          data.analysis.injury_type,
          data.analysis.severity,
          data.analysis.steps,
          data.source
        );
      }
    } catch (e) {
      console.error("Failed image analysis:", e);
    }
  }

  function showFirstAidLoading() {
    const card = document.getElementById('firstaid-results-card');
    card.classList.remove('hidden');
    document.getElementById('result-emergency-title').innerText = "Analyzing Emergency...";
    document.getElementById('result-steps-list').innerHTML = `<li><i class="fa-solid fa-spinner fa-spin"></i> Generating step-by-step guidance...</li>`;
  }

  function displayFirstAidResults(title, severity, steps, source) {
    const card = document.getElementById('firstaid-results-card');
    card.classList.remove('hidden');

    document.getElementById('result-emergency-title').innerText = title;

    // Source badge
    const sourceBadge = document.getElementById('result-source-badge');
    sourceBadge.innerText = source === 'ai' ? 'Source: AI Model' : 'Source: Offline Protocol';
    sourceBadge.className = source === 'ai' ? 'badge badge-ai' : 'badge badge-offline';

    // Severity badge
    const sevBadge = document.getElementById('result-severity-badge');
    sevBadge.className = `severity-pill severity-${severity.toLowerCase()}`;
    sevBadge.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> ${severity.toUpperCase()} SEVERITY`;

    // Render Steps
    const listEl = document.getElementById('result-steps-list');
    listEl.innerHTML = '';
    state.currentStepsForTTS = steps;

    steps.forEach(step => {
      const li = document.createElement('li');
      li.innerText = step;
      listEl.appendChild(li);
    });

    card.scrollIntoView({ behavior: 'smooth' });
  }

  function toggleTTS() {
    if ('speechSynthesis' in window) {
      if (window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel();
        document.getElementById('btn-tts-speak').innerHTML = `<i class="fa-solid fa-volume-high"></i> Read Aloud`;
        return;
      }

      if (!state.currentStepsForTTS || state.currentStepsForTTS.length === 0) return;

      const text = state.currentStepsForTTS.join('. ');
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = state.language === 'ta' ? 'ta-IN' : state.language === 'hi' ? 'hi-IN' : 'en-US';

      utterance.onend = () => {
        document.getElementById('btn-tts-speak').innerHTML = `<i class="fa-solid fa-volume-high"></i> Read Aloud`;
      };

      document.getElementById('btn-tts-speak').innerHTML = `<i class="fa-solid fa-volume-xmark"></i> Stop Speech`;
      window.speechSynthesis.speak(utterance);
    }
  }

  // ==================== SECTION 3: NEARBY HOSPITALS CONTROLLER ====================
  function setupHospitalsSection() {
    document.getElementById('btn-refresh-hospitals').addEventListener('click', () => {
      getUserLocation();
      loadNearbyHospitals();
    });

    // Specialty filter chips
    document.querySelectorAll('#specialty-chips .chip').forEach(chip => {
      chip.addEventListener('click', () => {
        document.querySelectorAll('#specialty-chips .chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        state.selectedSpecialty = chip.getAttribute('data-specialty');
        loadNearbyHospitals();
      });
    });

    document.getElementById('btn-close-route').addEventListener('click', () => {
      document.getElementById('modal-route').classList.add('hidden');
    });
  }

  async function loadNearbyHospitals() {
    const grid = document.getElementById('hospitals-grid');
    grid.innerHTML = `<div class="subtext"><i class="fa-solid fa-spinner fa-spin"></i> Locating nearest trauma centers...</div>`;

    try {
      let url = `/hospitals/nearby?lat=${state.userLat}&lng=${state.userLng}`;
      if (state.selectedSpecialty) {
        url += `&specialty=${encodeURIComponent(state.selectedSpecialty)}`;
      }

      const res = await fetch(url);
      const data = await res.json();

      if (data.success && data.hospitals) {
        renderHospitalsList(data.hospitals);
      }
    } catch (e) {
      grid.innerHTML = `<div class="text-danger">Failed to load hospital data.</div>`;
    }
  }

  function renderHospitalsList(hospitals) {
    const grid = document.getElementById('hospitals-grid');
    grid.innerHTML = '';

    if (hospitals.length === 0) {
      grid.innerHTML = `<div class="text-muted">No hospitals found matching selected criteria.</div>`;
      return;
    }

    hospitals.forEach(h => {
      const card = document.createElement('div');
      card.className = 'glass-card hospital-card';

      const specTags = h.specialties.map(s => `<span class="spec-tag">${s}</span>`).join('');

      card.innerHTML = `
        <div>
          <div class="hosp-top">
            <div>
              <h3 class="hosp-name">${h.name}</h3>
              <span class="badge ${h.trauma_level === 'Level 1' ? 'badge-ai' : 'badge-pending'}">${h.trauma_level} Trauma</span>
            </div>
            <div class="hosp-dist">${h.distance_km} km</div>
          </div>

          <div class="hosp-meta-row">
            <div class="hosp-meta-item"><i class="fa-solid fa-clock text-warning"></i> ${h.er_wait_minutes}m ER Wait</div>
            <div class="hosp-meta-item"><i class="fa-solid fa-bed text-success"></i> ${h.bed_availability} Beds</div>
          </div>

          <div class="hosp-specialties">${specTags}</div>
        </div>

        <div class="hosp-actions">
          <button class="btn btn-secondary btn-nav-route" data-name="${h.name}" data-dist="${h.distance_km}">
            <i class="fa-solid fa-route"></i> Navigate
          </button>
          <a href="tel:${h.phone}" class="btn btn-primary">
            <i class="fa-solid fa-phone"></i> Call ER
          </a>
        </div>
      `;

      card.querySelector('.btn-nav-route').addEventListener('click', () => {
        showNavigationRoute(h.name, h.distance_km);
      });

      grid.appendChild(card);
    });
  }

  function showNavigationRoute(hospName, distKm) {
    const modal = document.getElementById('modal-route');
    modal.classList.remove('hidden');

    document.getElementById('route-hosp-name').innerText = hospName;
    document.getElementById('route-hosp-dist').innerHTML = `<i class="fa-solid fa-road"></i> ${distKm} km away`;
    
    const eta = Math.ceil(distKm * 2.5); // ETA calculation
    document.getElementById('route-hosp-eta').innerHTML = `<i class="fa-solid fa-clock"></i> ${eta} mins ETA`;

    // Render Canvas Polyline Route
    const canvas = document.getElementById('route-canvas');
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += 30) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += 30) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
    }

    // Draw route path
    ctx.beginPath();
    ctx.moveTo(40, 180);
    ctx.lineTo(140, 150);
    ctx.lineTo(240, 70);
    ctx.lineTo(360, 100);
    ctx.lineTo(440, 50);
    ctx.strokeStyle = '#ff3b30';
    ctx.lineWidth = 5;
    ctx.stroke();

    // Start point
    ctx.fillStyle = '#3b82f6';
    ctx.beginPath(); ctx.arc(40, 180, 8, 0, Math.PI * 2); ctx.fill();

    // End point
    ctx.fillStyle = '#10b981';
    ctx.beginPath(); ctx.arc(440, 50, 10, 0, Math.PI * 2); ctx.fill();

    // Populate Waypoints
    const waypoints = [
      "Head North on Main Arterial Road towards Emergency Hub",
      "Turn right onto Expressway Bypass (2.1 km)",
      "Take the elevated flyover exit towards Hospital Zone",
      "Merge onto Medical Center Avenue (0.8 km)",
      "Arrive at Hospital Emergency Bay entrance on the left"
    ];

    const ol = document.getElementById('route-waypoints-ol');
    ol.innerHTML = waypoints.map(w => `<li>${w}</li>`).join('');
  }

  // ==================== SECTION 4: HARDWARE STUDIO CONTROLLER ====================
  function setupHardwareStudio() {
    document.getElementById('btn-req-gps').addEventListener('click', requestGPSHardware);
    document.getElementById('btn-start-cam').addEventListener('click', startCameraStream);
    document.getElementById('btn-snap-cam').addEventListener('click', captureCameraSnapshot);
    document.getElementById('btn-start-mic').addEventListener('click', startAudioAndVoiceTrigger);

    // Online status listener
    window.addEventListener('online', updateNetworkStatus);
    window.addEventListener('offline', updateNetworkStatus);
    updateNetworkStatus();
  }

  function updateGPSReadout(coords) {
    document.getElementById('hw-lat').innerText = coords.latitude.toFixed(5);
    document.getElementById('hw-lng').innerText = coords.longitude.toFixed(5);
    document.getElementById('hw-acc').innerText = `${coords.accuracy.toFixed(1)} m`;

    const badge = document.getElementById('perm-gps-badge');
    badge.innerText = 'Granted';
    badge.className = 'badge badge-granted';
  }

  function requestGPSHardware() {
    if ('geolocation' in navigator) {
      state.watchPosId = navigator.geolocation.watchPosition(
        (pos) => {
          state.userLat = pos.coords.latitude;
          state.userLng = pos.coords.longitude;
          updateGPSReadout(pos.coords);
        },
        (err) => {
          const badge = document.getElementById('perm-gps-badge');
          badge.innerText = 'Denied';
          badge.className = 'badge badge-denied';
        }
      );
    }
  }

  async function startCameraStream() {
    try {
      state.camStream = await navigator.mediaDevices.getUserMedia({ video: true });
      const videoEl = document.getElementById('hw-camera-video');
      videoEl.srcObject = state.camStream;
      document.getElementById('camera-overlay-placeholder').classList.add('hidden');
      document.getElementById('btn-snap-cam').disabled = false;

      const badge = document.getElementById('perm-cam-badge');
      badge.innerText = 'Granted';
      badge.className = 'badge badge-granted';
    } catch (e) {
      const badge = document.getElementById('perm-cam-badge');
      badge.innerText = 'Denied';
      badge.className = 'badge badge-denied';
    }
  }

  function captureCameraSnapshot() {
    const videoEl = document.getElementById('hw-camera-video');
    const canvas = document.getElementById('hw-camera-canvas');
    canvas.width = videoEl.videoWidth || 640;
    canvas.height = videoEl.videoHeight || 480;

    const ctx = canvas.getContext('2d');
    ctx.drawImage(videoEl, 0, 0, canvas.width, canvas.height);

    canvas.toBlob((blob) => {
      const file = new File([blob], "camera_snapshot.jpg", { type: "image/jpeg" });
      state.selectedImageFile = file;

      // Switch tab to first-aid section and analyze
      document.querySelector('[data-tab="firstaid-section"]').click();
      handleImageSelect(file);
      uploadAndAnalyzeImage();
    }, "image/jpeg");
  }

  async function startAudioAndVoiceTrigger() {
    try {
      state.audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioCtx.createMediaStreamSource(state.audioStream);
      state.analyserNode = audioCtx.createAnalyser();
      state.analyserNode.fftSize = 256;

      source.connect(state.analyserNode);
      updateDecibelMeter();

      const badge = document.getElementById('perm-mic-badge');
      badge.innerText = 'Granted';
      badge.className = 'badge badge-granted';

      setupSpeechRecognition();
    } catch (e) {
      const badge = document.getElementById('perm-mic-badge');
      badge.innerText = 'Denied';
      badge.className = 'badge badge-denied';
    }
  }

  function updateDecibelMeter() {
    if (!state.analyserNode) return;
    const dataArray = new Uint8Array(state.analyserNode.frequencyBinCount);
    state.analyserNode.getByteFrequencyData(dataArray);

    let sum = 0;
    for (let i = 0; i < dataArray.length; i++) {
      sum += dataArray[i];
    }
    const avg = sum / dataArray.length;
    const db = Math.round((avg / 255) * 100);

    document.getElementById('db-value-text').innerText = `${db} dB`;
    document.getElementById('db-bar-fill').style.width = `${db}%`;

    requestAnimationFrame(updateDecibelMeter);
  }

  function setupSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      document.getElementById('voice-listener-state').innerText = "Browser Unsupported";
      return;
    }

    state.speechRecog = new SpeechRecognition();
    state.speechRecog.continuous = true;
    state.speechRecog.interimResults = true;
    state.speechRecog.lang = 'en-US';

    state.speechRecog.onstart = () => {
      document.getElementById('voice-listener-state').innerText = "Active & Listening...";
      document.getElementById('voice-listener-state').className = "text-success";
    };

    state.speechRecog.onresult = (event) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript.toUpperCase();
        if (transcript.includes('HELP') || transcript.includes('EMERGENCY')) {
          state.speechRecog.stop();
          triggerPanicCountdown();
          break;
        }
      }
    };

    state.speechRecog.start();
  }

  function updateNetworkStatus() {
    const online = navigator.onLine;
    const dot = document.querySelector('.net-dot');
    const netTxt = document.getElementById('net-text');
    const hwTxt = document.getElementById('hw-net-status');

    if (online) {
      dot.className = 'net-dot online';
      netTxt.innerText = 'Online';
      if (hwTxt) hwTxt.innerHTML = `<i class="fa-solid fa-wifi"></i> Online`;
    } else {
      dot.className = 'net-dot offline';
      netTxt.innerText = 'Offline';
      if (hwTxt) hwTxt.innerHTML = `<i class="fa-solid fa-plane"></i> Offline (Local Protocol Active)`;
    }
  }

  // ==================== SECTION 5: CONTACTS MANAGER CONTROLLER ====================
  function setupContactsManager() {
    document.getElementById('btn-open-add-contact').addEventListener('click', () => openContactModal());
    document.getElementById('btn-close-contact-modal').addEventListener('click', closeContactModal);
    document.getElementById('btn-cancel-contact-form').addEventListener('click', closeContactModal);

    document.getElementById('form-contact').addEventListener('submit', handleContactFormSubmit);
  }

  async function loadContacts() {
    try {
      const res = await fetch('/contacts');
      const data = await res.json();
      if (data.success && data.contacts) {
        state.contacts = data.contacts;
        renderContactsList(data.contacts);
      }
    } catch (e) {
      console.error("Failed to load contacts:", e);
    }
  }

  function renderContactsList(contacts) {
    const grid = document.getElementById('contacts-grid');
    grid.innerHTML = '';

    contacts.forEach(c => {
      const card = document.createElement('div');
      card.className = `glass-card contact-card ${c.is_primary ? 'primary-contact' : ''}`;

      card.innerHTML = `
        <div>
          <div class="contact-header">
            <div>
              <h3 class="contact-name">${c.name}</h3>
              <span class="contact-relation">${c.relation}</span>
            </div>
            ${c.is_primary ? '<span class="badge badge-ai">Primary Contact</span>' : ''}
          </div>
          <div class="contact-phone"><i class="fa-solid fa-phone"></i> ${c.phone}</div>
        </div>

        <div class="contact-actions">
          <label class="toggle-label">
            <span class="toggle-switch">
              <input type="checkbox" class="chk-primary-toggle" ${c.is_primary ? 'checked' : ''}>
              <span class="slider"></span>
            </span>
            Primary
          </label>

          <div>
            <button class="btn-icon btn-edit-contact"><i class="fa-solid fa-pen-to-square"></i></button>
            <button class="btn-icon btn-delete-contact"><i class="fa-solid fa-trash-can text-danger"></i></button>
          </div>
        </div>
      `;

      // Toggle primary
      card.querySelector('.chk-primary-toggle').addEventListener('change', (e) => {
        updateContactPrimary(c.id, e.target.checked);
      });

      // Edit
      card.querySelector('.btn-edit-contact').addEventListener('click', () => {
        openContactModal(c);
      });

      // Delete
      card.querySelector('.btn-delete-contact').addEventListener('click', () => {
        deleteContact(c.id);
      });

      grid.appendChild(card);
    });
  }

  function openContactModal(contact = null) {
    const modal = document.getElementById('modal-contact-form');
    modal.classList.remove('hidden');

    if (contact) {
      document.getElementById('modal-contact-title').innerHTML = `<i class="fa-solid fa-pen-to-square text-primary"></i> Edit Emergency Contact`;
      document.getElementById('contact-id-field').value = contact.id;
      document.getElementById('contact-name-input').value = contact.name;
      document.getElementById('contact-phone-input').value = contact.phone;
      document.getElementById('contact-relation-input').value = contact.relation;
      document.getElementById('contact-primary-check').checked = contact.is_primary;
    } else {
      document.getElementById('modal-contact-title').innerHTML = `<i class="fa-solid fa-user-plus text-primary"></i> Add Emergency Contact`;
      document.getElementById('contact-id-field').value = '';
      document.getElementById('contact-name-input').value = '';
      document.getElementById('contact-phone-input').value = '';
      document.getElementById('contact-relation-input').value = '';
      document.getElementById('contact-primary-check').checked = false;
    }
  }

  function closeContactModal() {
    document.getElementById('modal-contact-form').classList.add('hidden');
  }

  async function handleContactFormSubmit(e) {
    e.preventDefault();

    const id = document.getElementById('contact-id-field').value;
    const payload = {
      name: document.getElementById('contact-name-input').value,
      phone: document.getElementById('contact-phone-input').value,
      relation: document.getElementById('contact-relation-input').value,
      is_primary: document.getElementById('contact-primary-check').checked
    };

    try {
      const url = id ? `/contacts/${id}` : '/contacts';
      const method = id ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (data.success) {
        closeContactModal();
        loadContacts();
      }
    } catch (e) {
      console.error("Failed saving contact:", e);
    }
  }

  async function updateContactPrimary(contactId, isPrimary) {
    const contact = state.contacts.find(c => c.id === contactId);
    if (!contact) return;

    try {
      await fetch(`/contacts/${contactId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: contact.name,
          phone: contact.phone,
          relation: contact.relation,
          is_primary: isPrimary
        })
      });
      loadContacts();
    } catch (e) {
      console.error("Failed to update primary contact status:", e);
    }
  }

  async function deleteContact(contactId) {
    if (!confirm("Are you sure you want to delete this emergency contact?")) return;

    try {
      const res = await fetch(`/contacts/${contactId}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        loadContacts();
      }
    } catch (e) {
      console.error("Failed to delete contact:", e);
    }
  }

  // Initialize
  init();

});
